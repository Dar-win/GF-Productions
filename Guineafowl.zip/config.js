module.exports = {
    mongoURI: 'mongodb+srv://gf-webmaster:GuineaFowlP1@cluster0.okidu.mongodb.net/guineafowl?retryWrites=true&w=majority',
};
