const _ = require("lodash")
const fs = require("fs")
const path = require("path")
const Jimp = require("jimp")
const crypto = require("crypto");
const mkdirp = require("mkdirp")
const concat = require("concat-stream");
const streamifier = require("streamifier");

const UPLOAD_PATH = path.resolve(__dirname, '..', process.env.IMAGE_STORAGE);
// const UPLOAD_PATH = path.resolve(__dirname, '..', process.env.DISPIMAGE_STORAGE);
//lg-500
//md-250
//sm-100
//thumb-50

let ImageStorage = () => {

    //constructor
    function ImageStorage() {
        let baseUrl = process.env.IMAGE_BASE_URL
        // let dispImageBaseUrl = process.env.DISPIMAGE_URL;

        let allowedStorageSystems = ['local'];
        let allowedOutputFormats = ['jpg', 'jpeg', 'png'];

        this.uploadPath = UPLOAD_PATH;
        this.uploadBaseUrl = baseUrl;

        !fs.existsSync(this.uploadPath) && mkdirp.sync(this.uploadPath);

    }

    ImageStorage.prototype._generateRandomFileName = function () {
        let bytes = crypto.pseudoRandomBytes(32);
        let checksum = crypto.createHash('MD5').update(bytes).digest('hex');

        return checksum + '.' +'jpg';
    }

    ImageStorage.prototype._createOutputStream = function (filepath, size, cb) {
        let that = this;
        let output = fs.createWriteStream(filepath);

        output.on('error', function (err) {
            console.log(err)
        });

        output.on('finish', ()=>{
            let imagePath;
            let imageUrl;
            switch (size) {
                case "lg":
                    imagePath = path.join(that.uploadPath, "500")
                    imageUrl = path.join(that.uploadBaseUrl, "500")
                    break;
                case "md":
                    imagePath = path.join(that.uploadPath, "250")
                    imageUrl = path.join(that.uploadBaseUrl, "250")
                    break;
                case "sm":
                    imagePath = path.join(that.uploadPath, "100")
                    imageUrl = path.join(that.uploadBaseUrl, "100")
                    break; 
                case "thumb":
                    imagePath = path.join(that.uploadPath, "20")
                    imageUrl = path.join(that.uploadBaseUrl, "20")
                    break;           
            
                default:
                    imagePath = that.uploadPath
                    imageUrl = that.uploadBaseUrl
                    break;
            }
            cb(null, {
                destination: imagePath,
                baseUrl: imageUrl,
                filename: path.basename(filepath),
                storage: "local"
            });
        });

        return output
    };

    ImageStorage.prototype._processImage = function (image, cb) {
        let that = this;
        let batch = [];

        let filename = this._generateRandomFileName();

        let mime = Jimp.MIME_JPEG;

        let lgClone = image.clone();
        let mdClone = image.clone();
        let smClone = image.clone();
        let thumbClone = image.clone();

        lgClone.resize(Jimp.AUTO, 500).quality(90);
        mdClone.resize(Jimp.AUTO, 250).quality(90);
        smClone.resize(Jimp.AUTO, 100).quality(90);
        thumbClone.resize(Jimp.AUTO, 20).quality(90);

        let outputStream;
        let filePath = filename.split(".");


        let thumbnailFilePath = filePath[0]+"_thumbnail"+"."+filePath[1];
        let dispImageFilePath = filePath[0] + "_disp" +"."+ filePath[1];
        
        let lgFilePath = path.join(that.uploadPath, "500", filename);
        let mdFilePath = path.join(that.uploadPath, "250", filename);
        let smFilePath = path.join(that.uploadPath, "100", filename);
        let thumbFilePath = path.join(that.uploadPath, "20", filename);

        // thumbnailFilePath = path.join(that.uploadPath, thumbnailFilePath);
        // dispImageFilePath = path.join(that.uploadPath, dispImageFilePath);

        let lgOutputStream = that._createOutputStream(lgFilePath, "lg", cb)
        let mdOutputStream = that._createOutputStream(mdFilePath, "md", cb)
        let smOutputStream = that._createOutputStream(smFilePath, "sm", cb)
        let thumbOutputStream = that._createOutputStream(thumbFilePath, "thumb", cb)



        // let thumbnailOutputStream = that._createOutputStream(thumbnailFilePath, cb);
        // let dispImageOutputStream = that._createOutputStream(dispImageFilePath, cb);
        let lgBatchObject = {
            stream: lgOutputStream,
            image: lgClone
        }
        let mdBatchObject = {
            stream: mdOutputStream,
            image: mdClone
        };
        let smBatchObject = {
            stream: smOutputStream,
            image: smClone
        };
        let thumbBatchObject = {
            stream: thumbOutputStream,
            image: thumbClone
        };
        // let image = new Jimp(300, 530, 'green', (err, image) => {
        //     if (err) throw err
        // })
          
        // let message = 'Hello!'
        // let x = 10
        // let y = 10
        
        // Jimp.loadFont(Jimp.FONT_SANS_64_BLACK)
        // .then(font => {
        //     image.print(font, x, y, message)
        //     return image
        // }).then(image => {
        //     let file = `new_name.${image.getExtension()}`
        //     return image.write(file) // save
        // })


        batch.push(lgBatchObject)
        batch.push(mdBatchObject);
        batch.push(smBatchObject)
        batch.push(thumbBatchObject);

        _.each(batch, (current) => {
            current.image.getBuffer(mime, (err, buffer) => {
                streamifier.createReadStream(buffer).pipe(current.stream);
            })
        });
        
    } 

    ImageStorage.prototype._handleFile = function (req, file, cb) {
        var that = this;

        let fileManipulate = concat((imageData) => {
            Jimp.read(imageData)
            .then((image) => {
                that._processImage(image, cb);
            })
            .catch(cb)
        })

        file.stream.pipe(fileManipulate)
    }

    ImageStorage.prototype._removeFile = function (req, file, cb) {
        let matches, pathsplit;
        let filename = file.filename;
        let _path = path.join(this.uploadPath, filename);

        let paths = [];

        delete file.filename;
        delete file.destination;
        delete file.baseUrl;
        delete file.storage;

        paths = [_path];

        _.each(paths, (_path) => {
            fs.unlink(_path, cb);
        });
    };

    return new ImageStorage()
}

module.exports = ImageStorage;
