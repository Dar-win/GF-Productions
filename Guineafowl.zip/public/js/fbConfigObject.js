let firebaseConfig = {
    apiKey: "AIzaSyCqD5u_jDmKFKyJpCuEK51tD1HPg-3w8TE",
    authDomain: "guineafowl-productions-308016.firebaseapp.com",
    projectId: "guineafowl-productions-308016",
    storageBucket: "guineafowl-productions-308016.appspot.com",
    messagingSenderId: "24924575954",
    appId: "1:24924575954:web:49e5546571dea9f8cd350b",
    measurementId: "G-SZLDDE9LRH"
  };


let app = firebase.initializeApp(firebaseConfig);
db = firebase.firestore(app);
firebase.analytics();