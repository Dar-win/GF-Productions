$(document).ready(()=>{
    $("#uploadImgBn").on("click", ()=>{
      let imageName = $("#imageName").val();
      let imageDescription = $("#imageDescription").val();
      let imagePrice = $("#imagePrice").val();
      let imageKeywords = $("#imageKeywords").val();
      let imageFile = $('#imageUpload')[0].files[0];

      if (imageName == "" || imagePrice == null|| imageDescription == "" || imageDescription == null || imagePrice == "" || imagePrice == null || imageKeywords == "" || imageKeywords == null) {
        alert("Please fill in all fields")
        return
      }

      if(imageFile == null){
        alert("Please choose an image")
        return
      }

      let formData = new FormData();
      formData.append('file', imageFile);
      formData.append("imageName", imageName);
      formData.append("imageDescription", imageDescription);
      formData.append("imagePrice", imagePrice);
      formData.append("imageKeywords", JSON.stringify(imageKeywords.split(", ")));

      $.ajax({
        url: '/upload/',
        dataType: "JSON",
        data: formData,
        type: "POST",
        processData: false,
        contentType: false,
        beforeSend: function(){
          $("#uploadForm").css({opacity: 0.5});
          $("#uploadImgBn").html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading your file...').addClass('disabled');
        }
      })
      .done((result)=>{
        if(result.success === true){
          formData.append("alias", result.alias)
          $.ajax({
            url: '/upload/uploadToDB/',
            dataType: "JSON",
            data: formData,
            type: "POST",
            processData: false,
            contentType: false
          }).done((res) => {
            alert("Image uploaded successfully");
            $("#uploadForm").css({opacity: 1});
            $("#uploadForm")[0].reset();
            $('#uploadImgBn').html("Upload").removeClass('disabled');
            $('#img-placeholder')
                  .attr('src', 'https://plchldr.co/i/500x250?text=Guineafowl%20Productions&bg=ecefff&fc=757575');

          })
            
        }else{
          alert("There was a problem")
          $("#uploadForm").css({opacity: 1})
          $('#uploadImgBn').html("Upload").removeClass('disabled');
        }
      })
      .catch((err)=>{
        $("#uploadForm").css({opacity: 1})
        alert("There was a problem uploading your image. Please try again");
        $('#uploadImgBn').html("Upload").removeClass('disabled');
      })
      

    })

  })
