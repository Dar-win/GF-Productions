function signIn() {
    $("#signInBtn").html('<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>Signing you in...').addClass('disabled')
    let email = $("#loginEmail").val();
    let password = $("#loginPassword").val()

   // if($('input[type=checkbox]').prop('checked')){
     //   firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL)
       // .then(() => {
         //   return firebase.auth().signInWithEmailAndPassword(email, password);
        //})
        //.catch((error) => {
          //  var errorCode = error.code;
           // var errorMessage = error.message;
           // alert(error.message)
           // $("#signInBtn").html('SIGN IN').removeClass('disabled')
       // });
   // }else{
        firebase.auth().setPersistence(firebase.auth.Auth.Persistence.SESSION)
        .then(() => {

            return firebase.auth().signInWithEmailAndPassword(email, password);
        })
        .catch((error) => {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(error.message);
            $("#signInBtn").html('SIGN IN').removeClass('disabled')
        });
   // }


    
}

function sendPasswordResetLink() {
    firebase.auth().sendPasswordResetEmail("webmaster@guineafowlproductions.co.ke").then(function() {
        alert("A password reset link has been sent to your email")
    }).catch(function(error) {
        alert(error)
    });
}


