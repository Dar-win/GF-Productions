$("#donateBtn").on('click', function () {
    let donatePhoneNumber = $("#donatePhoneNumber").val();
    let donateAmount = $("#donateAmount").val();

    let sanitizedPhoneNumber = sanitizePhoneNumber(donatePhoneNumber)
    if(sanitizedPhoneNumber=="#" ){
        alert("Wrong phone number format");
          // showAlert("danger", "phoneNumberFormatError");
          return;
    }
    if(donateAmount == "0"){
        alert("Please enter a valid amount");
        return;
    }

    $.ajax({
        type : 'POST',
        url : '/transactions/initiateLNMTransaction',
        data : {phoneNumber: sanitizedPhoneNumber, amount: donateAmount, accountRef: "GF-Donation"},
        dataType : "JSON",
        beforeSend: function(){
          $('#donateBtn').html('<span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span>Initiating Transaction...').addClass('disabled');
        }
      }).fail(function(response){
        $('#donateBtn').html("Donate").removeClass('disabled');
        alert("Error: "+JSON.stringify(response));
      }).done(function(response){
        if(response.ResponseCode == "0"){
          sessionStorage.setItem("checkoutRequestID", response.CheckoutRequestID);
          
          getReceiptRealTime("Donate", "#donateBtn", "donation", "{}");
        }else{
          $('#donateBtn').html("Donate").removeClass('disabled');
          alert(response.ResponseDescription);
        }
      }).always(function(response){
            
      });
    
})


