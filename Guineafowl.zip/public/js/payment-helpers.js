function sanitizePhoneNumber(phoneNumber){
    var sanitizedPhoneNumber = "";
    if (phoneNumber.length ==10 && phoneNumber.startsWith("07")){
        sanitizedPhoneNumber = phoneNumber.replace("0", "254");
    }else if(phoneNumber.length == 13 && phoneNumber.startsWith("+254")){
        sanitizedPhoneNumber = phoneNumber.replace("+254", "254");
    }else if(phoneNumber.length == 12 && phoneNumber.startsWith("254")){
        sanitizedPhoneNumber = phoneNumber;
    }else{
        sanitizedPhoneNumber = "#";
    }
    return sanitizedPhoneNumber;
  }

  function getReceiptRealTime(buttonText, buttonID, paymentFor, selectedImage){
    $(buttonID).html('<span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span>Verifying...').addClass('disabled');
    let id = sessionStorage.getItem("checkoutRequestID");
    // var id = "ws_CO_021020201411510801";
    let dataExists = "false";
    
    
    let unsubscribe = db.collection("mpesaCallbacks").doc(id).onSnapshot(function(doc) {
      var source = doc.metadata.hasPendingWrites ? "Local" : "Server";
      var callbackData = doc.data();
      
      if (callbackData != null && callbackData != ""){
        dataExists = "true";
        var resultCode = callbackData.resultCode;
        unsubscribe();
        clearTimeout(timeout);
        sessionStorage.removeItem("checkoutRequestID");

        if (resultCode == 0){
          $(buttonID).html(buttonText).removeClass('disabled');
          // showAlert("success", "verificationSuccess");
          if(paymentFor == "imagePurchase"){
              window.location = "/portfolio/image/"+selectedImage.name;
	      alert("Verification successful. Your file download should start shortly.");
          }else{
	      alert("Verification successful. Guineafowl Productions thanks you for your donation");
	     $("#donatePhoneNumber").val("");
	     $("#donateAmount").val("");
	  }
            
        } else {
          alert("Transaction failed: "+callbackData.resultDesc);
          $(buttonID).html(buttonText).removeClass('disabled');
            
        }
      }
    });


    let timeout = setTimeout(function(){
      if(dataExists == "false"){
        unsubscribe();
        alert("Sorry. Our servers could not find your payment. If you did not receive prompt to enter your M-Pesa PIN, kindly check if your SIM card is updated and can receive STK prompts. For further assistance, call us on 0797977992.");
      }
    }, 61000);
  }
