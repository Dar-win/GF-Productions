$(document).ready(function(){
    let images = [];
    let selectedImage = {};
    
    $.ajax({
      url:'/portfolio/loadImages',
      dataType: "JSON",
      type: "POST"
    }).done((result)=>{
      images = result.images 
      images.forEach(image => {
        pigObject = {};
        pigObject.filename = image.alias;
        pigObject.aspectRatio = image.aspectRatio;
        imageData.push(pigObject)
      });

      let options = {
        urlForSize: function(filename, size) {
          return '/uploads/' + size + '/' + filename;
        }
      };

      let pig = new Pig(imageData, options).enable();  
      let imageName = "";  
            
      $('.pig-figure').click(function(){
        let str = ($(this).html());
        let subStr = str.match("20/(.*)pig-thumbnail");
        imageName = subStr[1].split('" ')[0];
        images.forEach(image => {
          if (image.alias === imageName){
            selectedImage = image;
          }
            
        }) 
        $('#downloadImageModal').modal('show');
      });       
    }).catch((err)=>{
      console.log(err)
    });

    let imageData = [];
    $('#downloadImageModal').on('show.bs.modal', ()=>{
        let modal = $('#downloadImageModal');
        if(selectedImage.aspectRatio < 1){
          modal.find('.modal-body #modal-image').removeClass("landscape-image").addClass("portrait-image");
        }else{
          modal.find('.modal-body #modal-image').removeClass("portrait-image").addClass("landscape-image");
        }
          
        modal.find('.modal-title').text(selectedImage.description);
        modal.find('.modal-body #modal-image').attr("src", "/uploads/250/"+selectedImage.alias);
        if(selectedImage.price == "0"){
            modal.find('.modal-footer #downloadImageBtn').text("Download Free");
        }else{
            modal.find('.modal-footer #downloadImageBtn').text("Download Ksh "+ selectedImage.price);
        }
      });        
  

    $('#downloadImageModal').on('hidden.bs.modal', ()=>{
      let modal = $('#downloadImageModal');
      modal.find('.modal-title').text("");
      modal.find('.modal-footer #downloadImageBtn').text("Download");
      imageId = "";
      imageName = "";
    });

    $('#downloadImageBtn').on('click', ()=>{
      let buttonText = $("#downloadImageBtn").text();
      let modal = $('#downloadImageModal');
      
      if(selectedImage.price === 0){
        alert("Your download should start shortly");
        window.location = "/portfolio/image/"+selectedImage.name;
      }else{
        let confirmedPhoneNumber = prompt("Please enter your mpesa phone number");
        if(confirmedPhoneNumber==null || confirmedPhoneNumber ==""){
            alert("Please enter phone number");
            return;
        }
        var sanitizedPhoneNumber = sanitizePhoneNumber(confirmedPhoneNumber);
                
        if(sanitizedPhoneNumber=="#" ){
          alert("Wrong phone number format");
            return;
        }
        
        $.ajax({
          type : 'POST',
          url : '/transactions/initiateLNMTransaction',
          data : {phoneNumber: sanitizedPhoneNumber, amount: selectedImage.price, accountRef: "Image Purchase"},
          dataType : "JSON",
          beforeSend: function(){
            $('#downloadImageBtn').html('<span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span>Initiating Transaction...').addClass('disabled');
          }
        }).fail(function(response){
          $('#downloadImageBtn').html(buttonText).removeClass('disabled');
          alert("Error: "+JSON.stringify(response));
        }).done(function(response){
          if(response.ResponseCode == "0"){
            sessionStorage.setItem("checkoutRequestID", response.CheckoutRequestID);
            getReceiptRealTime(buttonText, "#downloadImageBtn", "imagePurchase", selectedImage);
          }else{
            $('#downloadImageBtn').html(buttonText).removeClass('disabled');
            alert(response.ResponseDescription);
          }
        }).always(function(response){
              
        });
      }
    })

  });
