const express = require('express');
const mongoose = require('mongoose');
const uploadController = require('../controllers/uploadController');
const config = require('../config')
const Image = require('../models/image')
const Jimp = require('jimp');
const path = require('path');
const _ = require('lodash');

var global = this;
const uploadRouter = express.Router();

var chunksArray = [];
let aspectRatio = 0;

// router.get('/', uploadController.load_page);
// router.post('/saveImage', uploadController.image_save);

// module.exports = router;

module.exports = (uploadGridFs, uploadImageStorage) => {
    const url = config.mongoURI;
    const connect = mongoose.createConnection(url, { useNewUrlParser: true, useUnifiedTopology: true });

    let gfs;
    let chunksGfs;

    connect.once('open', () => {
        // initialize stream
        gfs = new mongoose.mongo.GridFSBucket(connect.db, {
            bucketName: "uploads"
        });

        chunksGfs = connect.db.collection('uploads.chunks')
    });

    uploadRouter.route('/')
    .post(  (req, res, next) => {
        let alias = "";
        let upload = uploadImageStorage.single('file')
        
        try {
            upload(req, res, async (err)=>{
                let imagePath = path.join(req.file.destination, req.file.filename)
                let image = await Jimp.read(imagePath);
                let width = image.bitmap.width;
                let height = image.bitmap.height;
                aspectRatio = width/height;
                  
                alias = req.file.filename;
                if (req.fileValidationError) {
                    console.log("TAG1")
                    console.log(req.fileValidationError)
                    return res.send(req.fileValidationError);
                    
                }
                else if (!req.file) {
                    console.log("PLease select image to upload");
                    return res.send('Please select an image to upload');
                }
                else if (err) {
                    console.log(err)
                    return res.send(err);
                }
                res.json({
                    success: true,
                    alias: alias
                })
                
            })

        } catch (error) {
            console.log(error);
        }

    })
    .get((req, res, next) => {
        res.render('upload')
    });

    uploadRouter.route('/uploadToDB')
    .post((req, res, next) => {

        let dbUpload = uploadGridFs.single('file')
        dbUpload(req, res, (err) => {
            console.log(req.body)
            console.log(req.file);
            let image = new Image({
                name: req.file.filename,
                description: req.body.imageDescription,
                price: req.body.imagePrice,
                keywords: JSON.parse(req.body.imageKeywords),
                imageId: req.file.id,
                alias: req.body.alias,
                aspectRatio: aspectRatio
            });
            image.save()
            .then((img) => {
                res.status(200).json({success : true});
            })
            .catch((err)=>{
                console.log("TAG5");
                console.log(err)
                res.status(500).json(err);
            })
        })
    });

    uploadRouter.route('/multiple')
    .post(uploadGridFs.array('file', 3), (req, res, next) => {
        res.status(200).json({
            success: true,
            message: `${req.files.length} files uploaded successfully`,
        });
    });
    

    return uploadRouter;
};
