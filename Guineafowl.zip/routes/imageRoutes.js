const express = require('express');
const imageController = require('../controllers/imageController');

const imageRouter = express.Router();


imageRouter.get('/', imageController.images_render);
imageRouter.post('/loadImages', imageController.images_load);
imageRouter.get('/image/:filename', imageController.image_download);
imageRouter.get('/delete/:id', imageController.image_delete);
imageRouter.get('/recent', imageController.get_image_recent);
imageRouter.post('/file/del/:id', imageController.image_delete_gfs);

// router.get('/', uploadController.load_page);
// router.post('/saveImage', uploadController.image_save);

module.exports = imageRouter;


