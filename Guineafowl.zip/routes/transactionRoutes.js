const express = require('express');
const transactionController = require('../controllers/transactionController');

const transactionRouter = express.Router();


transactionRouter.post('/initiateLNMTransaction', transactionController.auth, transactionController.initiateTransaction);
transactionRouter.post('/callback', transactionController.transactionCallback);

module.exports = transactionRouter;